# Lab2Web - Praktikum 2: HTML Lanjutan

| | |
|---|---|
| **Nama** | Astuti |
| **NIM** | 312510320 |
| **Kelas** | I252A |
| **Mata Kuliah** | Pemrograman Web |
| **Universitas** | Universitas Pelita Bangsa, Bekasi |

## Struktur Folder

```
Lab2Web/
├── index.html        # Latihan langkah 1-8
├── semantic.html     # Langkah 7: halaman semantic HTML
├── biodata.html      # Proyek mini biodata mahasiswa
├── latihan/          # File HTML per langkah (01 - 09)
├── media/
│   ├── audio.mp3
│   └── video.mp4
├── screenshots/      # Dokumentasi hasil praktik
└── README.md
```

## Langkah Praktikum

### 1. Tabel Data Mahasiswa
Membuat tabel dengan `<table>`, `<tr>`, `<th>`, `<td>` berisi 4 data mahasiswa (lebih dari minimal 3).

### 2. Tabel dengan thead, tbody, tfoot
Menambahkan `<caption>`, `<thead>`, `<tbody>`, `<tfoot>`, dan `colspan="2"` pada baris rata-rata.

![Tabel](screenshots/01-tabel.png)

### 3-5. Form Registrasi, Radio, Checkbox, Select, Textarea
Form berisi input `text`, `email`, `password`, `date`, `radio`, `checkbox`, `file`, `select`, `textarea`, serta tombol `submit` dan `reset`. Setiap `<label>` dihubungkan dengan `id` input melalui atribut `for`.

![Form](screenshots/02-form.png)

### 6. Validasi Form Dasar
Menggunakan atribut `required`, `minlength`, `maxlength`, `min`, `max`, `type`, dan `pattern`. Saat tombol Kirim ditekan dalam keadaan kosong, browser menampilkan pesan validasi.

![Validasi](screenshots/03-validasi.png)

### 7. Semantic HTML
Halaman disusun dengan `<header>`, `<nav>`, `<main>`, `<section>`, `<article>`, `<aside>`, dan `<footer>`.

![Semantic](screenshots/04-semantic.png)

### 8. Multimedia
Menambahkan `<audio controls>` dan `<video controls>` dari folder `media/`.

![Multimedia](screenshots/05-multimedia.png)

### 9. Proyek Mini - Biodata Mahasiswa
`biodata.html` menggabungkan semantic HTML, tabel, form dengan validasi, dan elemen video.

![Biodata](screenshots/06-biodata.png)

## Cara Menjalankan
1. Buka folder `Lab2Web` di Visual Studio Code.
2. Klik kanan `index.html` lalu pilih **Open with Live Server** (atau buka langsung di browser).

## Jawaban Pertanyaan

**1. Apa fungsi `<table>`, `<tr>`, `<th>`, dan `<td>`?**
`<table>` membuat struktur tabel, `<tr>` membuat baris, `<th>` membuat sel header (judul kolom/baris), dan `<td>` membuat sel data.

**2. Apa perbedaan `<th>` dan `<td>`?**
`<th>` adalah sel header: teks dicetak tebal dan rata tengah secara default, serta bermakna sebagai judul. `<td>` adalah sel data biasa dengan tampilan normal.

**3. Apa fungsi `colspan` pada tabel?**
`colspan` menggabungkan beberapa kolom menjadi satu sel. Contoh `colspan="2"` membuat sel melebar selama dua kolom.

**4. Apa fungsi `<form>` dalam HTML?**
`<form>` adalah wadah untuk elemen input agar data dari pengguna dapat dikumpulkan dan dikirim ke server (melalui atribut `action` dan `method`).

**5. Apa perbedaan radio button dan checkbox?**
Radio button hanya memperbolehkan satu pilihan dalam satu grup (nama `name` sama), sedangkan checkbox memperbolehkan memilih satu, beberapa, atau tidak sama sekali.

**6. Mengapa `<label>` sebaiknya terhubung dengan `id` input melalui atribut `for`?**
Agar saat label diklik, fokus langsung pindah ke input terkait (area klik lebih luas, terutama untuk radio/checkbox), serta membantu aksesibilitas karena screen reader dapat membacakan label yang sesuai.

**7. Apa perbedaan `<textarea>` dengan input type text?**
`<textarea>` untuk teks panjang banyak baris dan ukurannya diatur dengan `rows`/`cols`. `input type="text"` hanya untuk teks satu baris.

**8. Apa fungsi semantic HTML?**
Memberi makna pada struktur halaman: `<header>` kepala halaman, `<nav>` navigasi, `<main>` konten utama, `<section>` pengelompokan konten, `<article>` konten mandiri, `<aside>` konten pelengkap, dan `<footer>` kaki halaman. Manfaatnya kode lebih mudah dibaca, lebih baik untuk SEO dan aksesibilitas.

**9. Apa fungsi `required`, `min`, `max`, dan `minlength`?**
`required` membuat input wajib diisi, `min` dan `max` menentukan nilai minimum dan maksimum (angka/tanggal), `minlength` menentukan panjang teks minimum.

**10. Apa perbedaan elemen `<audio>` dan `<video>`?**
`<audio>` memutar suara saja (hanya tampil kontrol pemutar), sedangkan `<video>` memutar gambar bergerak beserta suara dan dapat diatur ukurannya (`width`, `height`).

## Checklist
- [x] Tabel berhasil ditampilkan dan memiliki header
- [x] Form memiliki label dan beberapa jenis input
- [x] Radio button dan checkbox digunakan
- [x] Select dan textarea digunakan
- [x] Validasi required dan validasi lainnya dicoba
- [x] Semantic HTML digunakan
- [x] Audio dan video ditampilkan
- [x] Proyek mini biodata menggabungkan materi utama
- [x] Screenshot dan README.md tersedia
